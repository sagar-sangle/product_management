package com.nimapinfotech.product_cateogory_crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCateogoryCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductCateogoryCrudApplication.class, args);
	}

}
