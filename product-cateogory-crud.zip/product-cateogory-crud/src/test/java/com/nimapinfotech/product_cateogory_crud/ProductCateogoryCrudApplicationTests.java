package com.nimapinfotech.product_cateogory_crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductCateogoryCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
